#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stddef.h>

void print_to_file(int n, double** A, int format_flag) {
    char filename[50];
    sprintf(filename, "array_%06d_", n);

    if (format_flag == 0) {
        strcat(filename, "asc.out");
        FILE* fp = fopen(filename, "w");
        if (fp == NULL) {
            fprintf(stderr, "Error opening %s for writing\n", filename);
            return;
        }

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                fprintf(fp, "%.15e   ", A[i][j]);
            }
            fprintf(fp, "\n");
        }
        fclose(fp);
    } else if (format_flag == 1) {
        strcat(filename, "bin.out");
        FILE* fp = fopen(filename, "wb");
        if (fp == NULL) {
            fprintf(stderr, "Error opening %s for writing\n", filename);
            return;
        }
        fwrite(&n, sizeof(int), 1, fp);
        for (int i = 0; i < n; i++) {
            fwrite(A[i], sizeof(double), n, fp);
        }
        fclose(fp);
    }
}


int main() {
    FILE* fp = fopen("input.in", "r");
    if (fp == NULL) {
        fprintf(stderr, "Error opening input.in\n");
        return 1;
    }
    int n;
    if (fscanf(fp, "%d", &n) != 1) {
        fprintf(stderr, "Error reading n from input.in\n");
        fclose(fp);
        return 1;
    }
    fclose(fp);

    double** A = (double**)malloc(n * sizeof(double*));
    if (A == NULL) {
        fprintf(stderr, "Memory allocation failed for rows\n");
        return 1;
    }

    for (int i = 0; i < n; i++) {
        A[i] = (double*)malloc(n * sizeof(double));
        if (A[i] == NULL) {
            fprintf(stderr, "Memory allocation failed for columns\n");
            for (int j = 0; j < i; j++)
                free(A[j]);
            free(A);
            return 1;
        }
    }

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++)
            A[i][j] = i + j;
    }


    print_to_file(n, A, 0); // First call with format_flag = 0
    print_to_file(n, A, 1); // Second call with format_flag = 1

  FILE* asc_file_fp = fopen("array_004000_asc.out", "r");
    if (asc_file_fp == NULL) {
      fprintf(stderr, "Error opening array_004000_asc.out for size check\n");
    } else{
        fseek(asc_file_fp, 0, SEEK_END);
        long asc_file_size = ftell(asc_file_fp);
        fclose(asc_file_fp);
        printf("Approximate size of array_004000_asc.out: %ld bytes\n", asc_file_size);
    }

    FILE* bin_file_fp = fopen("array_004000_bin.out", "rb");
      if (bin_file_fp == NULL) {
        fprintf(stderr, "Error opening array_004000_bin.out for size check\n");
      } else{
        fseek(bin_file_fp, 0, SEEK_END);
        long bin_file_size = ftell(bin_file_fp);
        fclose(bin_file_fp);
       printf("Approximate size of array_004000_bin.out: %ld bytes\n", bin_file_size);
      }


    for (int i = 0; i < n; i++)
        free(A[i]);
    free(A);

    printf("The array files have been generated.\n");
    return 0;
}