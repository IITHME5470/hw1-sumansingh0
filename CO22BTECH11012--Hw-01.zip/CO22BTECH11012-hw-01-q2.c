#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <float.h>
#include <stdbool.h>
#include <math.h>

void readMatrix(const char *filename, double **matrix, int n)
{
    FILE *file = fopen(filename, "r");
    if (file == NULL)
    {
        fprintf(stderr, "Error opening matrix file %s\n", filename);
        return;
    }

    char line[1024];
    for (int i = 0; i < n; i++)
    {
        if (fgets(line, sizeof(line), file) == NULL)
        {
            fprintf(stderr, "Error reading row %d from %s\n", i, filename);
            fclose(file);
            return;
        }

        char *token = strtok(line, ",");
        for (int j = 0; j < n; j++)
        {
            if (token == NULL)
            {
                fprintf(stderr, "Error reading element at [%d][%d] from %s\n", i, j, filename);
                fclose(file);
                return;
            }
            matrix[i][j] = atof(token);
            token = strtok(NULL, ",");
        }
    }
    fclose(file);
}

void readVectors(const char *filename, double *vec, int n)
{
    FILE *file = fopen(filename, "r");
    if (file == NULL)
    {
        fprintf(stderr, "Error opening vector file %s\n", filename);
        return;
    }

    char line[1024];
    if (fgets(line, sizeof(line), file) == NULL)
    {
        fprintf(stderr, "Error reading vector from %s\n", filename);
        fclose(file);
        return;
    }

    char *token = strtok(line, ",");
    for (int i = 0; i < n; i++)
    {
        if (token == NULL)
        {
            fprintf(stderr, "Error reading element at index %d from %s\n", i, filename);
            fclose(file);
            return;
        }
        vec[i] = atof(token);
        token = strtok(NULL, ",");
    }
    fclose(file);
}

double *matrix_vector_product(double **matrix, double *vector, int n)
{
    double *result = (double *)malloc(n * sizeof(double));
    if (result == NULL)
    {
        fprintf(stderr, "Memory allocation failed during matrix-vector multiplication\n");
        return NULL;
    }
    for (int i = 0; i < n; i++)
    {
        result[i] = 0.0;
        for (int j = 0; j < n; j++)
            result[i] += matrix[i][j] * vector[j];
    }
    return result;
}

double findEigenval(double **A, double *vec, int n, double tolerance)
{
    double *mat_vec_prod = matrix_vector_product(A, vec, n);
    if (mat_vec_prod == NULL)
        return DBL_MAX;

    double eigenvalue;
    if (vec[0] != 0)
        eigenvalue = mat_vec_prod[0] / vec[0];
    else
    {
        free(mat_vec_prod);
        return DBL_MAX;
    }

    for (int i = 1; i < n; i++)
        if (fabs(mat_vec_prod[i] - eigenvalue * vec[i]) > tolerance)
        {
            free(mat_vec_prod);
            return DBL_MAX;
        }
    free(mat_vec_prod);
    return eigenvalue;
}

void appendEigenvalue(const char *filename, double eigenValue)
{
    FILE *file = fopen(filename, "a");
    if (file == NULL)
    {
        fprintf(stderr, "Error opening vector file %s for appending\n", filename);
        return;
    }
    fprintf(file, "\n%e", eigenValue);
    fclose(file);
}

void freeMemory(double **array, int n)
{
    for (int i = 0; i < n; i++)
    {
        free(array[i]);
    }
    free(array);
}

void stripPath(char *filename)
{
    char *last_slash = strrchr(filename, '/');
    if (last_slash != NULL)
    {
        memmove(filename, last_slash + 1, strlen(last_slash));
    }
}

int main()
{
    int n;
    double tolerance = 1e-6;
    FILE *file = fopen("input.in", "r");
    if (file == NULL)
    {
        fprintf(stderr, "Error opening input file\n");
        return 1;
    }

    fscanf(file, "%d", &n);
    fclose(file);

    // Allocate 2D array for matrix
    double **A = (double **)malloc(n * sizeof(double *));
    for (int j = 0; j < n; j++)
    {
        A[j] = (double *)malloc(n * sizeof(double));
    }

    // Read matrix from file
    char matFile[50];
    sprintf(matFile, "mat_%06d.in", n);
    readMatrix(matFile, A, n);

    // Read vectors from files
    for (int j = 0; j < 4; j++)
    {
        char vecInput[50];
        sprintf(vecInput, "vec_%06d_%06d.in", n, j + 1);

        double *vec = (double *)malloc(n * sizeof(double));
        readVectors(vecInput, vec, n);
        if (vec != NULL)
        {
            double eigenValue = findEigenval(A, vec, n, tolerance);
            char vecOutput[50];
            strcpy(vecOutput, vecInput);
            stripPath(vecOutput);
            if (eigenValue != DBL_MAX)
            {
                printf("%s : Valid Eigenvector : %e \n", vecOutput, eigenValue);
                appendEigenvalue(vecInput, eigenValue);
            }
            else
            {
                printf("%s : Not an eigenvector\n", vecOutput);
            }
            free(vec);
        }
    }

    freeMemory(A, n);
    printf("\n");
    return 0;
}
